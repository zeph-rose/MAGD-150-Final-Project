const points = [];
let dragPoint = null;

const numPoints = 3;
const dragRadius = 20;
let img;
let colorPicker;
let colorFormat = 'hex'; // Default format
var title = "Dress-Up Game";
var shownImage = 0
function setup() {
  createCanvas(700, 500);

for(let i = 0; i< numPoints; i ++){
  points.push(createVector(random(width), random(height)));
}

  textFont("Great Vibes");
    
   // Create color picker
  colorPicker = createColorPicker('#93B694'); 
  colorPicker.position(25, 410);
  colorPicker.size(50,50);
  
audioPlayer = createAudio('lofi.music.mp3');
audioPlayer.showControls();
audioPlayer.attribute();
  
}

function preload(){
    img1 = loadImage("Frog.png");
	img2 = loadImage("Bunny.png");
    img3 = loadImage("Blue.png");
    
    img4 = loadImage("daisy skirt.png");
    img5 = loadImage("daisy shirt.png");
    img6 = loadImage("Daisy Hairclip.png");


}

function draw() {
  background('#FBFAD5');

for(let p of points){
  circle(p.x, p.y, dragRadius * 2);
}

  push();

image(img4,mouseX - 87,mouseY - 100,175,200);
image(img5,350,100,175,200);
image(img6,375,50,80,80);


pop();

  push();
  
  textSize(36);
  
  fill('#000000');
  
  line(100,75,350,75); //title align line
  textAlign(LEFT,BASELINE);
  text(title,110,50);
  
  
  textSize(12);
  text("Background",20,375,20,75);
  text("Color",35,400);
  
 //get the color from the color picker
    let selectedColor = colorPicker.color(); //background color select
  
  fill(colorPicker.value());
  
  audioPlayer.speed(1+ mouseX/windowWidth); //Audio for Game
  
  rect(100,75,250,365); //game screen
  
  rect(25,75,50,75); //character button one
  image(img1, 15, 75, 60, 75) //character button image 1
  
 if (mouseIsPressed == true && mouseX > 25 == true && mouseX < 75 && mouseY > 75 == true && mouseY < 150) {
   image(img1, 50, 75, 300, 350); //Frog Image Insert Screen
  } 
  
  rect(25,175,50,75); //character button two
  image(img2, 15, 175, 65, 75); // character button image 2
  
   if (mouseIsPressed == true && mouseX > 25 == true && mouseX < 75 && mouseY > 175 == true && mouseY < 250) {
   image(img2, 50, 75, 300, 350); //Bunny Image Insert Screen
  } 
  
  rect(25,275,50,75); //character button three
  image(img3, 15, 275, 65, 75); // character button image 3
  
   if (mouseIsPressed == true && mouseX > 25 == true && mouseX < 75 && mouseY > 275 == true && mouseY < 350) {
    image(img3, 50, 75, 300, 350); //Blue Image Insert Screen

    pop();



    
  } 
 


}

function mousePressed(){
  for(let i = points.length - 1; i >= 0; i --){
    if(mouseInCircle(points[i], dragRadius)){
      dragPoint = points.splice(i, 1);
      dragPoint.x = mouseX;
      dragPoint.y = mouseY;
      // bring the drag point to the front
      points.push(dragPoint);

      break;
    }
  }
}

function mouseDragged(){
  if(dragPoint){
    dragPoint.x = mouseX;
    dragPoint.y = mouseY;
  }
}

function mouseReleased() {
  dragPoint = null;
}

function mouseInCircle(pos, radius){
  return dist(mouseX, mouseY, pos.x, pos.y) < radius

}