let img;
let colorPicker;
let colorFormat = 'hex'; // Default format
var title = "Dress-Up Game";

function setup() {
  createCanvas(500, 500);
  
  textFont("Great Vibes")
    
   // Create color picker
  colorPicker = createColorPicker('#93B694'); 
  colorPicker.position(25, 410);
  colorPicker.size(50,50);
  
audioPlayer = createAudio('lofi.music.mp3');
audioPlayer.showControls();
audioPlayer.attribute();
  
}

function preload(){
    img1 = loadImage("Frog.png");
	img2 = loadImage("Bunny.png");
    img3 = loadImage("Blue.png");

}

function draw() {
  background('#FBFAD5');
  
  textSize(36);
  
  fill('#000000');
  
  line(100,75,350,75); //title align line
  textAlign(LEFT,BASELINE);
  text(title,110,50);
  
  
  textSize(12);
  text("Background",20,375,20,75);
  text("Color",35,400);
  
 //get the color from the color picker
    let selectedColor = colorPicker.color(); //background color select
  
  fill(colorPicker.value());
  
  audioPlayer.speed(1+ mouseX/windowWidth); //Audio for Game
  
  rect(100,75,250,365); //game screen
  
  rect(25,75,50,75); //character button one
  image(img1, 25, 75, 60, 75)
  
 if (mouseIsPressed == true && mouseX > 25 == true && mouseX < 75 && mouseY > 75 == true && mouseY < 150) {
   image(img1, 75, 75, 300, 350); //Frog Image Insert
  } 
  
  rect(25,175,50,75); //character button two
  image(img2, 20, 175, 65, 75);
  
   if (mouseIsPressed == true && mouseX > 25 == true && mouseX < 75 && mouseY > 175 == true && mouseY < 250) {
   image(img2, 75, 75, 300, 350); //Bunny Image Insert
  } 
  
  rect(25,275,50,75); //character button three
  
   if (mouseIsPressed == true && mouseX > 25 == true && mouseX < 75 && mouseY > 275 == true && mouseY < 350) {
   rect(200,200,100,200); //Blue Image Insert
  } 
  
  // Right Triangle Buttons
  triangle(375,115,385,110,385,120);
  triangle(375,215,385,210,385,220);
  triangle(375,315,385,310,385,320);
  triangle(375,415,385,410,385,420);
  
  // Left Triangle Buttons
  triangle(475,115,465,110,465,120);
  triangle(475,215,465,210,465,220);
  triangle(475,315,465,310,465,320);
  triangle(475,415,465,410,465,420);
  
}
