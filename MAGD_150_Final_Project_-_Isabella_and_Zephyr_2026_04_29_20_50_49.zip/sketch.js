let colorPicker;
let colorFormat = 'hex'; // Default format
var title = "Dress-Up Game";

function setup() {
  createCanvas(500, 500);
  
  textFont("Great Vibes")
    
   // Create color picker, defaulting to white
  colorPicker = createColorPicker('#A24646'); 
  colorPicker.position(25, 410);
  colorPicker.size(50,50);
}

function draw() {
  background(220);
  
  textSize(36);
  
  fill('#000000');
  
  line(100,75,350,75); //title align line
  textAlign(LEFT,BASELINE);
  text(title,110,50);
  
  
  textSize(12);
  text("Background",20,375,20,75);
  text("Color",35,400);
  
 //get the color from the color picker
    let selectedColor = colorPicker.color();
  
  fill(colorPicker.value());
  
  rect(100,75,250,365); //game screen
  
  rect(25,75,50,75); //character button one
  rect(25,175,50,75); //character button two
  rect(25,275,50,75); //character button three
  
  
}

