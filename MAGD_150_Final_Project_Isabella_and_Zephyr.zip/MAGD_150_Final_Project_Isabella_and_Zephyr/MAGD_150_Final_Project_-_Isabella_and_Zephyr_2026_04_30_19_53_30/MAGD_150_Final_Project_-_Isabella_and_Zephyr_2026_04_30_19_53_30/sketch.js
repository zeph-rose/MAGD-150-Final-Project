const points = [];
let dragPoint = null;

const numPoints = 5;
const dragRadius = 20;
let img;
let colorPicker;
let colorFormat = 'hex'; // Default format
var title = "Dress-Up Game";
var shownImage;
var w = 300; 
var h = 350;
var x = 50;
var y = 75;

function setup() {
  createCanvas(700, 500);

for(let i = 0; i< numPoints; i ++){
  points.push(createVector(random(width), random(height)));
}

  textFont("Great Vibes");
    
   // Create color picker
  colorPicker = createColorPicker('#93B694'); 
  colorPicker.position(25, 410);
  colorPicker.size(50,50);
  
audioPlayer = createAudio('lofi.music.mp3');
audioPlayer.showControls();
audioPlayer.attribute();
  
}

function preload(){
    img1 = loadImage("Frog.png");
	img2 = loadImage("Bunny.png");
    img3 = loadImage("Blue.png");
    
    img4 = loadImage("daisy skirt.png");
    img5 = loadImage("daisy shirt.png");
    img6 = loadImage("Daisy Hairclip.png");


}

function draw() {
  background('#FBFAD5');

for(let p of points){
  circle(p.x, p.y, dragRadius * 2);
}

  push();



pop();

  push();
  
  textSize(36);
  
  fill('#000000');
  
  line(100,75,300,75); //title align line
  textAlign(LEFT,BASELINE);
  text(title,100,50);
  
  
  textSize(12);
  text("Background",20,375,20,75);
  text("Color",35,400);
  
 //get the color from the color picker
    let selectedColor = colorPicker.color(); //background color select
  
  fill(colorPicker.value());
  
  audioPlayer.speed(1+ mouseX/windowWidth); //Audio for Game
  
  rect(100,y,225,365); //game screen
  
  rect(25,y,x,y); //character button one
  image(img1, 15, y, 65, 75) //character button image 1

  rect(25,y + 100,x,y); //character button two
  image(img2, 15, y + 100, 65, 75); // character button image 2

  rect(25,y + 200,x,y); //character button three
  image(img3, 15, y + 200, 65, 75); // character button image 3
  
 if (shownImage == 1) {
   image(img1, x, y, w, h); //Frog Image Insert Screen
  } else if (shownImage == 2) {
   image(img2, x, y, w, h); //Bunny Image Insert Screen
  } else if (shownImage == 3) {
    image(img3, x, y, w, h); //Blue Image Insert Screen

    pop();

    
  } 
 


}

function mousePressed(){
  
if(mouseIsPressed == true && mouseX > 25 == true && mouseX < y && mouseY > y == true && mouseY < 150){
  shownImage=1;
}else if(mouseIsPressed == true && mouseX > 25 == true && mouseX < y && mouseY > y+100 == true && mouseY < 250){
  shownImage=2;
}else if(mouseIsPressed == true && mouseX > 25 == true && mouseX < y && mouseY > y+200 == true && mouseY < 350){
  shownImage=3;
}


  for(let i = points.length - 1; i >= 0; i --){
    if(mouseInCircle(points[i], dragRadius)){
      dragPoint = points.splice(i, 1);
      dragPoint.x = mouseX;
      dragPoint.y = mouseY;
      // bring the drag point to the front
      points.push(dragPoint);

      break;


    }
  }
}

function mouseDragged(){
  if(dragPoint){
    dragPoint.x = mouseX;
    dragPoint.y = mouseY;
  }
}

function mouseReleased() {
  dragPoint = null;
}

function mouseInCircle(pos, radius){
  return dist(mouseX, mouseY, pos.x, pos.y) < radius

}