const points = [];
let dragPoint = null;

const numPoints = 5;
const dragRadius = 20;
let img;
let colorPicker;
let colorFormat = 'hex'; // Default format
var title = "Dress-Up Game";
var shownImage;
var shownImageCH;
var shownImageCSh;
var shownImageCB;
var w = 300; 
var h = 350;
var x = 50;
var y = 75;

function setup() {
  createCanvas(650, 500);

for(let i = 0; i< numPoints; i ++){
  points.push(createVector(random(width), random(height)));
}

  textFont("Great Vibes");
    
   // Create color picker
  colorPicker = createColorPicker('#93B694'); 
  colorPicker.position(25, 410);
  colorPicker.size(50,50);
  
audioPlayer = createAudio('lofi.music.mp3');
audioPlayer.showControls();
audioPlayer.attribute();
  
}

function preload(){
    img1 = loadImage("Frog.png");
	img2 = loadImage("Bunny.png");
    img3 = loadImage("Blue.png");
    
    img4 = loadImage("daisy skirt.png");
    img5 = loadImage("daisy shirt.png");
    img6 = loadImage("Daisy Hairclip.png");

img7 = loadImage("Buffy Hat.png");
img8 = loadImage("Buffy Shirt.png");
img9 = loadImage("Buffy Bottoms.png");


img10 = loadImage("Sprout Hat.png");
img11 = loadImage("Sprout Shirt.png");
img12 = loadImage("Sprout Bottoms.png");
}

function draw() {
  background('#FBFAD5');

for(let p of points){
  circle(p.x, p.y, dragRadius * 2);
}

  push();



pop();

  push();
  
  textSize(36);
  
  fill('#000000');
  
  line(100,75,300,75); //title align line
  textAlign(LEFT,BASELINE);
  text(title,100,50);
  
  

  textSize(12);
  text("Background",20,375,20,75);
  text("Color",35,400);

  text("By:", 500, 450);
  text("Zephyr Christianson", 500, 465);
  text("& Isabella Wahl", 500, 480);
  
 //get the color from the color picker
    let selectedColor = colorPicker.color(); //background color select
  
  fill(colorPicker.value());
  
  audioPlayer.speed(1+ mouseX/windowWidth); //Audio for Game
  
  rect(100,y,225,365); //game screen
  
  rect(25,y,x,y); //character button one
  image(img1, 15, y, 65, 75) //character button image 1

  rect(25,y + 100,x,y); //character button two
  image(img2, 15, y + 100, 65, 75); // character button image 2

  rect(25,y + 200,x,y); //character button three
  image(img3, 15, y + 200, 65, 75); // character button image 3
  
rect(350, y, x, y); // clothing button 1.1
image(img6, 350, y+10, 45, 55); // clothing button image 1.1

rect(350, y+100, x, y); // clothing button 1.2
image(img5, 350, y+110, 45, 55) // clothing button image 1.2

rect(350, y+200, x, y); // clothing button 1.3
image(img4, 350, y+210, 45, 55); // clothing button image 1.3

rect(450, y, x, y); // clothing button 2.1
image(img7, 450, y+10, 45, 55); // clothing button image 2.1

rect(450, y+100, x, y); // clothing button 2.2
image(img8, 450, y+110, 45, 55) // clothing button image 2.2

rect(450, y+200, x, y); // clothing button 2.3
image(img9, 450, y+210, 45, 55); // clothing button image 2.3

rect(550, y, x, y); // clothing button 3.1
image(img10, 550, y+10, 45, 55); // clothing button image 3.1

rect(550, y+100, x, y); // clothing button 3.2
image(img11, 550, y+110, 45, 55) // clothing button image 3.2

rect(550, y+200, x, y); // clothing button 3.3
image(img12, 550, y+210, 45, 55); // clothing button image 3.3

 if (shownImage == 1) {
   image(img1, x, y, w, h); //Frog Image Insert Screen
  } else if (shownImage == 2) {
   image(img2, x, y-10, w, h); //Bunny Image Insert Screen
  } else if (shownImage == 3) {
    image(img3, x, y, w, h); //Blue Image Insert Screen
} 
    pop();

    push();
if (shownImageCH == 1) {
    image(img6, 225, 125, 50, 50); //Daisy Hairclip Image Insert Screen
}else if (shownImageCH == 2) {
    image(img7, 110, 25, 200, 200); //Luffy Hat Image Insert Screen
}else if (shownImageCH == 3) {
    image(img10, 175, 90, 65, 65); //Sprout Hat Image Insert Screen
}
    pop();

     push();
if (shownImageCSh == 1) {
    image(img5, 125, 200, 150, 150); //Daisy Shirt Image Insert Screen
}else if (shownImageCSh == 2) {
    image(img8, 145, 215, 125, 125); //Luffy Shirt Image Insert Screen
}else if (shownImageCSh == 3) {
    image(img11, 140, 220, 125, 125); //Sprout Shirt Image Insert Screen
}
    pop();

     push();
if (shownImageCB == 1) {
    image(img4, 120, 265, 160, 160); //Daisy Bottoms Image Insert Screen
}else if (shownImageCB == 2) {
    image(img9, 140, 290, 120, 120); //Luffy Bottoms Image Insert Screen
}else if (shownImageCB == 3) {
    image(img12, 140, 290, 120, 120); //Sprout Bottoms Image Insert Screen
}
    pop();
  
 


}

function mousePressed(){
  
if(mouseIsPressed == true && mouseX > 25 == true && mouseX < y && mouseY > y == true && mouseY < 150){
  shownImage=1;
}else if(mouseIsPressed == true && mouseX > 25 == true && mouseX < y && mouseY > y+100 == true && mouseY < 250){
  shownImage=2;
}else if(mouseIsPressed == true && mouseX > 25 == true && mouseX < y && mouseY > y+200 == true && mouseY < 350){
  shownImage=3;
}

if(mouseIsPressed == true && mouseX > 350 == true && mouseX < 425 && mouseY > y+10 == true && mouseY < 150){
  shownImageCH=1;
}else if(mouseIsPressed == true && mouseX > 450 == true && mouseX < 525 && mouseY > y+10 == true && mouseY < 150){
  shownImageCH=2;
}else if(mouseIsPressed == true && mouseX > 550 == true && mouseX < 625 && mouseY > y+10 == true && mouseY < 150){
  shownImageCH=3;
}

if(mouseIsPressed == true && mouseX > 350 == true && mouseX < 425 && mouseY > y+110 == true && mouseY < 250){
  shownImageCSh=1;
}else if(mouseIsPressed == true && mouseX > 450 == true && mouseX < 525 && mouseY > y+110 == true && mouseY < 250){
  shownImageCSh=2;
}else if(mouseIsPressed == true && mouseX > 550 == true && mouseX < 625 && mouseY > y+110 == true && mouseY < 250){
  shownImageCSh=3;
}

if(mouseIsPressed == true && mouseX > 350 == true && mouseX < 425 && mouseY > y+210 == true && mouseY < 350){
  shownImageCB=1;
}else if(mouseIsPressed == true && mouseX > 450 == true && mouseX < 525 && mouseY > y+210 == true && mouseY < 350){
  shownImageCB=2;
}else if(mouseIsPressed == true && mouseX > 550 == true && mouseX < 625 && mouseY > y+210 == true && mouseY < 350){
  shownImageCB=3;
}

  for(let i = points.length - 1; i >= 0; i --){
    if(mouseInCircle(points[i], dragRadius)){
      dragPoint = points.splice(i, 1);
      dragPoint.x = mouseX;
      dragPoint.y = mouseY;
      // bring the drag point to the front
      points.push(dragPoint);

      break;


    }
  }
}

function mouseDragged(){
  if(dragPoint){
    dragPoint.x = mouseX;
    dragPoint.y = mouseY;
  }
}

function mouseReleased() {
  dragPoint = null;
}

function mouseInCircle(pos, radius){
  return dist(mouseX, mouseY, pos.x, pos.y) < radius

}